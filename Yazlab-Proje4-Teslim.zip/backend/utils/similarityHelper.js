/**
 * Dense Embedding Tabanlı Kosinüs Benzerliği
 *
 * Proje Gereksinimi (Madde 3): "Haberler arasında metin benzerliği analizi
 * (embedding tabanlı benzerlik ölçümü ile) yapılmalıdır."
 *
 * Forum Açıklaması: "Embedding tabanlı benzerlik ölçümünü önceden eğitilmiş
 * Yapay Zeka / Derin Öğrenme dil modelleri ile tespit etmeniz beklenmektedir."
 *
 * Yaklaşım:
 *   1. Model: sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2
 *      - 50+ dil desteği (Türkçe dahil)
 *      - 384 boyutlu dense embedding üretir
 *      - Sentence-BERT mimarisi (Siamese ağ yapısı)
 *   2. Çalışma ortamı: @xenova/transformers (ONNX Runtime)
 *      - Node.js'de lokal çalışır, API anahtarı gerektirmez
 *      - Model ilk kullanımda indirilir ve önbelleğe alınır
 *   3. Kosinüs benzerliği: 0–100 arası yüzde olarak döner
 *
 * Neden bu model?
 *   - Türkçe haber metinlerinde yüksek kaliteli anlamsal benzerlik
 *   - Lokal çalışır — internet bağımlılığı yok (ilk indirme hariç)
 *   - Ücretsiz — API maliyeti yok
 *   - MiniLM mimarisi küçük ve verimli
 */

let pipelineInstance = null;
let pipelineLoading = null;

/**
 * Singleton pattern ile model pipeline'ını yükle.
 * İlk çağrıda model indirilir (~120MB), sonraki çağrılarda önbellekten gelir.
 */
async function getPipeline() {
    if (pipelineInstance) return pipelineInstance;

    // Eşzamanlı çağrılarda tekrar yüklemeyi önle
    if (pipelineLoading) return pipelineLoading;

    pipelineLoading = (async () => {
        console.log('🧠 Embedding modeli yükleniyor (paraphrase-multilingual-MiniLM-L12-v2)...');
        const startTime = Date.now();

        const { pipeline } = await import('@xenova/transformers');

        pipelineInstance = await pipeline(
            'feature-extraction',
            'Xenova/paraphrase-multilingual-MiniLM-L12-v2',
            {
                // Quantized model — daha küçük boyut, daha hızlı
                quantized: true,
            }
        );

        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`✅ Embedding modeli yüklendi. (${elapsed} saniye)`);
        return pipelineInstance;
    })();

    return pipelineLoading;
}

/**
 * Metin için dense embedding hesapla.
 *
 * Sentence-BERT modeli kullanarak 384 boyutlu dense vektör üretir.
 * Mean pooling + L2 normalizasyon uygulanır.
 *
 * @param {string} text - Ham haber metni (başlık + içerik)
 * @returns {number[]} 384 boyutlu normalize edilmiş dense embedding vektörü
 */
async function getEmbedding(text) {
    if (!text || text.trim().length === 0) {
        return new Array(384).fill(0);
    }

    try {
        const extractor = await getPipeline();

        // Model max 512 token kabul eder — metni kısalt
        // Türkçe'de ortalama ~4 karakter/token, güvenli sınır ~1800 karakter
        const truncatedText = text.substring(0, 1800);

        const output = await extractor(truncatedText, {
            pooling: 'mean',       // Mean pooling — cümle seviyesi embedding
            normalize: true,       // L2 normalizasyon — kosinüs benzerliği için ideal
        });

        // Tensor'dan düz array'e dönüştür
        return Array.from(output.data);
    } catch (error) {
        console.error('❌ Embedding hesaplama hatası:', error.message);
        return new Array(384).fill(0);
    }
}

/**
 * Kosinüs benzerliği — 0–100 aralığında yüzde.
 *
 * Normalize edilmiş vektörler için dot product = kosinüs benzerliği.
 *
 * @param {number[]} vecA
 * @param {number[]} vecB
 * @returns {number} 0-100 arası benzerlik yüzdesi
 */
function calculateCosineSimilarity(vecA, vecB) {
    if (!vecA || !vecB || vecA.length !== vecB.length) return 0;

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }

    if (normA === 0 || normB === 0) return 0;

    const similarity = dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    // Sayısal hassasiyet sınırlama (-1 ile 1 arası garanti)
    return Math.min(1, Math.max(-1, similarity)) * 100;
}

module.exports = { getEmbedding, calculateCosineSimilarity };
