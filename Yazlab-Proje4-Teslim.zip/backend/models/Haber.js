const mongoose = require('mongoose');

const HaberSchema = new mongoose.Schema({
    baslik: {
        type: String,
        required: true,
        trim: true
    },
    icerik: {
        type: String,
        required: true
    },
    ozet: { type: String }, // Önizleme için
    haberTuru: {
        type: String,
        // Yazlab Proje I — yalnızca zorunlu beş haber türü
        enum: ['Trafik Kazası', 'Yangın', 'Elektrik Kesintisi', 'Hırsızlık', 'Kültürel Etkinlikler'],
        required: true
    },
    tarih: {
        type: Date,
        default: Date.now
    },
    kaynaklar: [{
        siteAdi: { type: String, required: true },
        link: { type: String, required: true },
        yayinTarihi: { type: Date }
    }],
    konum: {
        hamMetin: { type: String },
        ilce: { type: String }, // Arayüz ilçe filtresi için kanonik il adı (örn. İzmit)
        lat: { type: Number },
        lng: { type: Number },
        geoStatus: { type: Boolean, default: false }
    },
    // PDF Madde 3: Metin Benzerliği
    embedding: {
        type: [Number], // Vektör verisi burada tutulacak
        select: false // Normal sorgularda gelmesin, performans için
    }
}, { timestamps: true });

HaberSchema.index({ 'kaynaklar.link': 1 });
HaberSchema.index({ tarih: -1 });
HaberSchema.index({ haberTuru: 1 });
HaberSchema.index({ 'konum.ilce': 1 });

module.exports = mongoose.model('Haber', HaberSchema);